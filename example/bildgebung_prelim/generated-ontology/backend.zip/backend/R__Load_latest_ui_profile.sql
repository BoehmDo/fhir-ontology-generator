--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg120+2)
-- Dumped by pg_dump version 16.2 (Debian 16.2-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: context; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.context (id, system, code, version, display) FROM stdin;
1	mii.bg	BILDGEBUNG		Bildgebung
\.


--
-- Data for Name: mapping; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapping (id, name, type, content) FROM stdin;
\.


--
-- Data for Name: termcode; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.termcode (id, system, code, version, display) FROM stdin;
1	http://dicom.nema.org/resources/ontology/DCM	OPV	01	Ophthalmic Visual Field
2	http://dicom.nema.org/resources/ontology/DCM	SM	01	Slide Microscopy
3	http://dicom.nema.org/resources/ontology/DCM	BI	01	Biomagnetic imaging
4	http://dicom.nema.org/resources/ontology/DCM	IVOCT	01	Intravascular Optical Coherence Tomography
5	http://dicom.nema.org/resources/ontology/DCM	KER	01	Keratometry
6	http://dicom.nema.org/resources/ontology/DCM	ES	01	Endoscopy
7	http://dicom.nema.org/resources/ontology/DCM	US	01	Ultrasound
8	http://dicom.nema.org/resources/ontology/DCM	CT	01	Computed Tomography
9	http://dicom.nema.org/resources/ontology/DCM	IO	01	Intra-oral Radiography
10	http://dicom.nema.org/resources/ontology/DCM	DG	01	Diaphanography
11	http://dicom.nema.org/resources/ontology/DCM	PX	01	Panoramic X-Ray
12	http://dicom.nema.org/resources/ontology/DCM	OPM	01	Ophthalmic Mapping
13	http://dicom.nema.org/resources/ontology/DCM	OSS	01	Optical Survace Scanner
14	http://dicom.nema.org/resources/ontology/DCM	TG	01	Thermography
15	http://dicom.nema.org/resources/ontology/DCM	HD	01	Hemodynamic Waveform
16	http://dicom.nema.org/resources/ontology/DCM	IVUS	01	Intravascular Ultrasound
17	http://dicom.nema.org/resources/ontology/DCM	AR	01	Autorefraction
18	http://dicom.nema.org/resources/ontology/DCM	LEN	01	Lensometry
19	http://dicom.nema.org/resources/ontology/DCM	OCT	01	Optical Coherence Tomography
20	http://dicom.nema.org/resources/ontology/DCM	RF	01	Radiofluoroscopy
21	http://dicom.nema.org/resources/ontology/DCM	NM	01	Nuclear Medicine
22	http://dicom.nema.org/resources/ontology/DCM	LS	01	Laser surface scan
23	http://dicom.nema.org/resources/ontology/DCM	XA	01	X-Ray Angiography
24	http://dicom.nema.org/resources/ontology/DCM	ECG	01	Electrocardiography
25	http://dicom.nema.org/resources/ontology/DCM	XC	01	External-camera Photography
26	http://dicom.nema.org/resources/ontology/DCM	GM	01	General Microscopy
27	http://dicom.nema.org/resources/ontology/DCM	OPT	01	Ophthalmic Tomography
28	http://dicom.nema.org/resources/ontology/DCM	OAM	01	Ophthalmic Axial Measurements
29	http://dicom.nema.org/resources/ontology/DCM	BDUS	01	Ultrasound Bone Densitometry
30	http://dicom.nema.org/resources/ontology/DCM	EPS	01	Cardiac Electrophysiology
31	http://dicom.nema.org/resources/ontology/DCM	SRF	01	Subjective Refraction
32	http://dicom.nema.org/resources/ontology/DCM	BMD	01	Bone Mineral Densitometry
33	http://dicom.nema.org/resources/ontology/DCM	RTIMAGE	01	Radiotherapy Image
34	http://dicom.nema.org/resources/ontology/DCM	VA	01	Visual Acuity
35	http://dicom.nema.org/resources/ontology/DCM	CR	01	Computed Radiography
36	http://dicom.nema.org/resources/ontology/DCM	MG	01	Mammography
37	http://dicom.nema.org/resources/ontology/DCM	DX	01	Digital Radiography
38	http://dicom.nema.org/resources/ontology/DCM	RG	01	Radiographic imaging
39	http://dicom.nema.org/resources/ontology/DCM	PT	01	Positron emission tomography
40	http://dicom.nema.org/resources/ontology/DCM	MR	01	Magnetic Resonance
41	http://dicom.nema.org/resources/ontology/DCM	OP	01	Ophthalmic photography
\.


--
-- Data for Name: ui_profile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ui_profile (id, name, ui_profile) FROM stdin;
1	SD_MII_BILDGEBUNG	{\n    "attributeDefinitions": [\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "bodySite",\n                "display": "K\\u00f6rperstelle",\n                "system": "http://hl7.org/fhir/StructureDefinition",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referenceCriteriaSet": null,\n            "referencedOnlyOnce": false,\n            "selectableConcepts": [\n                {\n                    "code": "818982008",\n                    "display": "Abdominopelvic cross-sectional segment",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "70258002",\n                    "display": "Ankle joint structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "15825003",\n                    "display": "Aortic structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "361078006",\n                    "display": "Area of internal auditory canal",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "91470000",\n                    "display": "Axillary region structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "51299004",\n                    "display": "Bone structure of clavicle",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "89546000",\n                    "display": "Bone structure of cranium",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "71341001",\n                    "display": "Bone structure of femur",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "85050009",\n                    "display": "Bone structure of humerus",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "91609006",\n                    "display": "Bone structure of mandible",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "54735007",\n                    "display": "Bone structure of sacrum",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "79601000",\n                    "display": "Bone structure of scapula",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "12738006",\n                    "display": "Brain structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "76752008",\n                    "display": "Breast structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "69105007",\n                    "display": "Carotid artery structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "71252005",\n                    "display": "Cervix uteri structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "71854001",\n                    "display": "Colon structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "818981001",\n                    "display": "Cross-sectional abdomen",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "816092008",\n                    "display": "Cross-sectional pelvis",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "38848004",\n                    "display": "Duodenal structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "16953009",\n                    "display": "Elbow joint structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "38266002",\n                    "display": "Entire body as a whole",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "89545001",\n                    "display": "Face structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "7569003",\n                    "display": "Finger structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "56459004",\n                    "display": "Foot structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "14975008",\n                    "display": "Forearm structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "28231008",\n                    "display": "Gallbladder structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "85562004",\n                    "display": "Hand structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "69536005",\n                    "display": "Head structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "80891009",\n                    "display": "Heart structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "24136001",\n                    "display": "Hip joint structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "661005",\n                    "display": "Jaw region structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "64033007",\n                    "display": "Kidney structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "72696002",\n                    "display": "Knee region structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "66019005",\n                    "display": "Limb structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "10200004",\n                    "display": "Liver structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "122496007",\n                    "display": "Lumbar spine structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "39607008",\n                    "display": "Lung structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "72410000",\n                    "display": "Mediastinal structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "417437006",\n                    "display": "Neck and chest",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "45048000",\n                    "display": "Neck structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "15776009",\n                    "display": "Pancreatic structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "45289007",\n                    "display": "Parotid gland structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "41216001",\n                    "display": "Prostatic structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "34402009",\n                    "display": "Rectum structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "16982005",\n                    "display": "Shoulder region structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "78961009",\n                    "display": "Splenic structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "69695003",\n                    "display": "Stomach structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "53840002",\n                    "display": "Structure of calf of leg",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "1217257000",\n                    "display": "Structure of cervical and/or thoracic vertebral column region",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "122494005",\n                    "display": "Structure of cervical vertebral column",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "774007",\n                    "display": "Structure of head and/or neck",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "1217253001",\n                    "display": "Structure of lumbar and/or sacral vertebral column region",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "363654007",\n                    "display": "Structure of orbit proper",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "1217256009",\n                    "display": "Structure of thoracic and/or lumbar vertebral column region",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "421060004",\n                    "display": "Structure of vertebral column",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "68367000",\n                    "display": "Thigh structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "43799004",\n                    "display": "Thoracic cavity structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "122495006",\n                    "display": "Thoracic spine structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "76505004",\n                    "display": "Thumb structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "87953007",\n                    "display": "Ureteric structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "74670003",\n                    "display": "Wrist joint structure",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                }\n            ],\n            "singleReference": null,\n            "type": "concept"\n        },\n        {\n            "allowedUnits": [],\n            "attributeCode": {\n                "code": "laterality",\n                "display": "laterality",\n                "system": "http://hl7.org/fhir/StructureDefinition",\n                "version": null\n            },\n            "max": null,\n            "min": null,\n            "optional": true,\n            "precision": 1,\n            "referenceCriteriaSet": null,\n            "referencedOnlyOnce": false,\n            "selectableConcepts": [\n                {\n                    "code": "51440002",\n                    "display": "Right and left",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "419161000",\n                    "display": "Unilateral left",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                },\n                {\n                    "code": "419465000",\n                    "display": "Unilateral right",\n                    "system": "http://snomed.info/sct",\n                    "version": "http://snomed.info/sct/900000000000207008/version/20240101"\n                }\n            ],\n            "singleReference": null,\n            "type": "concept"\n        }\n    ],\n    "name": "SD_MII_BILDGEBUNG",\n    "timeRestrictionAllowed": true,\n    "valueDefinition": null\n}
\.


--
-- Data for Name: contextualized_termcode; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contextualized_termcode (context_termcode_hash, context_id, termcode_id, mapping_id, ui_profile_id) FROM stdin;
64811571-2c67-34eb-b429-b1a92c7596b8	1	17	\N	1
f2448c02-d10e-3871-8d01-11ed0ad8f93e	1	3	\N	1
f69652a8-da4b-38d9-95e1-3217f2f8b8d5	1	32	\N	1
04395990-3f20-3528-95b1-12c77667eb33	1	30	\N	1
9f0538f0-2d26-3b44-9fa5-b8a7a17f7f0f	1	35	\N	1
70f64bda-0679-37ad-b6c3-3d629326be6d	1	8	\N	1
ed457b43-cd18-3151-84cf-2e8e441d39d7	1	10	\N	1
ee8db09d-bcda-38fe-9137-378f4072df2a	1	37	\N	1
3bc05caa-ac14-3443-84fb-fabf4f7ea07b	1	24	\N	1
c66e4737-ea0c-3cc9-9cb4-1facb1c86891	1	6	\N	1
42dbc6cd-c36a-31c1-b7d9-33d4648e83d9	1	25	\N	1
6d943dd2-8cbd-3683-80b1-33e04d0cbcf4	1	26	\N	1
c31a92e4-d5d0-3d0b-9320-25b37adf8181	1	15	\N	1
082bfde8-5535-3fde-b8fe-7582c8a73c83	1	9	\N	1
07a0d5e9-1711-32dc-94c5-317868e7120d	1	4	\N	1
337525a1-81a7-379e-9e11-f419a1d02c9f	1	16	\N	1
456c14dc-7b39-3166-ad48-a4d18d66851a	1	5	\N	1
74a372ba-91bd-3631-b06b-7be136f2cba2	1	22	\N	1
a1c4ddcd-a140-3dfe-98c8-ae4c67387d03	1	18	\N	1
9c64820b-5a29-366f-b4d8-d4606bc76f88	1	40	\N	1
b5999d05-3fa6-3502-b609-aac84b90a11e	1	36	\N	1
a7574a40-ca86-39a0-93d7-7da3c62ccbf1	1	21	\N	1
726017f7-c081-302e-bd34-d97fe6b96925	1	28	\N	1
6eb1b1c5-5187-3100-bb62-b756297f9186	1	12	\N	1
5d43eb30-ce86-3865-a33f-57b5a2ae4e83	1	41	\N	1
52ccd953-af9b-398a-8789-91acc15ffcae	1	27	\N	1
1936ed59-faef-3047-9419-019dcd24c655	1	1	\N	1
41a64413-5e80-3e74-91e5-5abb5777218a	1	19	\N	1
06cda99e-7b1b-3c0e-9c68-fbec674a25f5	1	13	\N	1
3ed9c17b-e48d-3d0d-bc6e-547e568f96e8	1	11	\N	1
ee3e6a00-1a0a-3520-8a15-84e9ffb190ef	1	39	\N	1
6c2296cc-a193-3d11-b83f-559e2d713b8f	1	20	\N	1
1a0f81e0-37c4-36e5-b6fd-19e4be97193d	1	38	\N	1
bbcdbd95-6f65-3973-aeb1-cb5aceb7bad4	1	33	\N	1
3ce01190-a29d-3603-86b2-3c6afcddbc3f	1	2	\N	1
ebe9e57d-59e0-3252-81b5-f3d3ac2dcc48	1	31	\N	1
98dbbcc8-33bb-39d7-8511-6f71823a3710	1	14	\N	1
1ca67731-b8ed-387e-9a29-fa5347a3b5a4	1	7	\N	1
44c653ed-736a-3fdb-9119-b532453677fb	1	29	\N	1
9c083148-f732-3194-b796-f41c3151770f	1	34	\N	1
3502fb3b-8df0-324c-b42d-fbad73366703	1	23	\N	1
\.


--
-- Data for Name: criteria_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.criteria_set (id, url) FROM stdin;
\.


--
-- Data for Name: contextualized_termcode_to_criteria_set; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contextualized_termcode_to_criteria_set (context_termcode_hash, criteria_set_id) FROM stdin;
\.


--
-- Name: context_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.context_id_seq', 1, true);


--
-- Name: criteria_set_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.criteria_set_id_seq', 1, false);


--
-- Name: mapping_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mapping_id_seq', 1, false);


--
-- Name: termcode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.termcode_id_seq', 41, true);


--
-- Name: ui_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ui_profile_id_seq', 1, true);


--
-- PostgreSQL database dump complete
--

